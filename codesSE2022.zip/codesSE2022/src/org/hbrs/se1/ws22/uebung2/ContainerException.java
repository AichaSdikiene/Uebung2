package org.hbrs.se1.ws22.uebung2;

public class ContainerException extends Exception{
    public ContainerException(String msg){
        super(msg);
    }

}
