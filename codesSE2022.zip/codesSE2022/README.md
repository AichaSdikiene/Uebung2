# GitHub-Seite der Vorlesung SE-1 (Prof. Alda)

Auf dieser Seite finden sie die Source-Codes aus den Übungen sowie Demo-Codes aus den Vorlesungen.

(Hinweis: diese Seite ist im Aufbau)

### Hilfreiche Video-Tutorien:

[Teil 1: Installation IntelliJ und Entwicklung eines Java-Projekts mit JUnit5](https://www.youtube.com/watch?v=TNtRpkdW64s ) 

[Teil 2: Clone eines GitHub-Repository mit IntelliJ (sorry für die Verzögerung bei der Demo der Export-Funktion)](https://www.youtube.com/watch?v=5nr4c3pwu3g)
